<?php
   // error_reporting(0);
	$host='localhost';
	$username='root';
	$password="";
	$database='lib_database';
?>